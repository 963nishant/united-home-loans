package com.lti.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Customer;


@Transactional
@Repository
public class AdminDaoImpl implements IAdminDao
{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	

@Override
public List<Customer> custlist()
 {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String query="from Customer";
		Query q=session.createQuery(query);
		List<Customer> custlist=q.list();
		System.out.println(custlist);
		tx.commit();
		session.close();
		return custlist;
	}

@Override
public void acceptCust(String emailId) {
	Session session = this.sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	String query="update Customer c set c.loanStatus='ACCEPTED' where c.emailId=:emailId";
	Query q=session.createQuery(query);
	q.setString("emailId", emailId);
	q.executeUpdate();
	tx.commit();
	/*Transaction tx1=session.beginTransaction();
	String query1="insert into Customer ()
	Query q1=session.createQuery(query1);
	q1.executeUpdate();
	tx1.commit();
	session.close();*/
}
	
	


@Override
public void rejectCust(String emailId) {
	Session session = this.sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	String query="update Customer c  set c.requestStatus='REJECTED' where c.emailId=:emailId";
	Query q=session.createQuery(query);
	q.setString("emailId",emailId);

	q.executeUpdate();
	tx.commit();
	session.close();
	
}
}